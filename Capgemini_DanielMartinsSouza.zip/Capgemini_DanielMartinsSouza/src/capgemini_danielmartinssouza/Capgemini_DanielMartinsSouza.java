package capgemini_danielmartinssouza;

import java.util.ArrayList;
import java.util.LinkedList;
import java.util.List;
import java.util.Scanner;

/**
 * @author Daaniel Martins de Souza - Umuarama PR
 */
public class Capgemini_DanielMartinsSouza {

    public static void questao01() {
        /**
         * Questão 01 - Escreva um algoritmo que mostre na tela uma escada de
         * tamanho n utilizando o caractere * e espaços. A base e altura da
         * escada devem ser iguais ao valor de n. A última linha não deve conter
         * nenhum espaço.
         */

        System.out.println("Questão 01");
        Scanner teclado = new Scanner(System.in);
        System.out.print("Qual será o tamaho da escada? ");
        int n = teclado.nextInt();
        int aux1 = n;
        String espacos = "";
        String asteriscos = "";
        for (int i = 0; i < n; i++) {
            for (int j = 0; j < aux1; j++) {
                if (j == (aux1 - 1)) {
                    break;
                }
                espacos += " ";
            }
            for (int j = 0; j <= i; j++) {
                asteriscos += "*";
            }
            System.out.println(espacos + asteriscos);
            espacos = "";
            asteriscos = "";
            aux1 -= 1;
        }
    }

    public static void questao02() {
        /**
         * Questão 02 - Para ajudar Débora, construa um algoritmo que informe
         * qual é o número mínimo de caracteres que devem ser adicionados para
         * uma string qualquer ser considerada segura
         */

        System.out.println("Questão 02");
        Scanner teclado = new Scanner(System.in);
        System.out.print("Qual foi a senha informada? ");
        String senha = teclado.nextLine();
        List<Character> senhaQuebrada = new ArrayList<>();
        for (char c : senha.toCharArray()) {
            senhaQuebrada.add(c);
        }

        for (int i = 0; i < 1; i++) {
            if (senha.length() < 6) {
                System.out.println("É preciso acrescentar pelo menos mais " + (6 - senha.length()) + " caracteres!");
                break;
            }
            if (encontrouDigito(senhaQuebrada) == false) {
                System.out.println("É preciso acrescentar pelo menos um dígito numeral!");
                break;
            }
            if (encontrouMinuscula(senhaQuebrada) == false) {
                System.out.println("É preciso pelo menos uma letra minúscula!");
                break;
            }
            if (encontrouMaiuscula(senhaQuebrada) == false) {
                System.out.println("É preciso pelo menos uma letra maiuscula!");
                break;
            }
            if (encontrouCaracterEspecial(senhaQuebrada) == false) {
                System.out.println("É preciso pelo menos um dos seguintes caracteres especial: !@#$%^&*()-+");
                break;
            }
            System.out.println("Sua senha é forte!");
            break;
        }

    }

    public static void questao03() {
        /**
         * Questão 03 - Duas palavras podem ser consideradas anagramas de si
         * mesmas se as letras de uma palavra podem ser realocadas para formar a
         * outra palavra. Dada uma string qualquer, desenvolva um algoritmo que
         * encontre o número de pares de substrings que são anagramas.
         */

        System.out.println("Questão 03");
        Scanner teclado = new Scanner(System.in);
        System.out.print("Qual foi a palavra? ");
        String palavra = teclado.nextLine();
        List<Character> palavraQuebrada = new ArrayList<>();
        for (char c : palavra.toCharArray()) {
            palavraQuebrada.add(c);
        }
        System.out.println("O número de pares de substrings anagramas encontrados"
                + " é de: " + (compararLetrasIguais(palavraQuebrada)));
    }

    //Busca por um dígito numeral na senha informada no exercício 02
    public static boolean encontrouDigito(List<Character> senhaQuebrada) {
        for (int i = 0; i < senhaQuebrada.size(); i++) {
            if (senhaQuebrada.get(i) == '0' || senhaQuebrada.get(i) == '1'
                    || senhaQuebrada.get(i) == '2' || senhaQuebrada.get(i) == '3'
                    || senhaQuebrada.get(i) == '4' || senhaQuebrada.get(i) == '5'
                    || senhaQuebrada.get(i) == '6' || senhaQuebrada.get(i) == '7'
                    || senhaQuebrada.get(i) == '8' || senhaQuebrada.get(i) == '9') {
                return true;
            }
        }
        return false;
    }

    //Busca por uma letra minúscula na senha informada no exercício 02
    public static boolean encontrouMinuscula(List<Character> senhaQuebrada) {
        for (int i = 0; i < senhaQuebrada.size(); i++) {
            if (senhaQuebrada.get(i) == 'a' || senhaQuebrada.get(i) == 'b'
                    || senhaQuebrada.get(i) == 'c' || senhaQuebrada.get(i) == 'd'
                    || senhaQuebrada.get(i) == 'e' || senhaQuebrada.get(i) == 'f'
                    || senhaQuebrada.get(i) == 'g' || senhaQuebrada.get(i) == 'h'
                    || senhaQuebrada.get(i) == 'i' || senhaQuebrada.get(i) == 'j'
                    || senhaQuebrada.get(i) == 'k' || senhaQuebrada.get(i) == 'l'
                    || senhaQuebrada.get(i) == 'm' || senhaQuebrada.get(i) == 'n'
                    || senhaQuebrada.get(i) == 'o' || senhaQuebrada.get(i) == 'p'
                    || senhaQuebrada.get(i) == 'q' || senhaQuebrada.get(i) == 'r'
                    || senhaQuebrada.get(i) == 's' || senhaQuebrada.get(i) == 't'
                    || senhaQuebrada.get(i) == 'u' || senhaQuebrada.get(i) == 'v'
                    || senhaQuebrada.get(i) == 'w' || senhaQuebrada.get(i) == 'x'
                    || senhaQuebrada.get(i) == 'y' || senhaQuebrada.get(i) == 'z') {
                return true;
            }
        }
        return false;
    }

    //Busca por uma letra maiúscula na senha informada no exercício 02
    public static boolean encontrouMaiuscula(List<Character> senhaQuebrada) {
        for (int i = 0; i < senhaQuebrada.size(); i++) {
            if (senhaQuebrada.get(i) == 'a' || senhaQuebrada.get(i) == 'b'
                    || senhaQuebrada.get(i) == 'c' || senhaQuebrada.get(i) == 'd'
                    || senhaQuebrada.get(i) == 'e' || senhaQuebrada.get(i) == 'f'
                    || senhaQuebrada.get(i) == 'g' || senhaQuebrada.get(i) == 'h'
                    || senhaQuebrada.get(i) == 'i' || senhaQuebrada.get(i) == 'j'
                    || senhaQuebrada.get(i) == 'k' || senhaQuebrada.get(i) == 'l'
                    || senhaQuebrada.get(i) == 'm' || senhaQuebrada.get(i) == 'n'
                    || senhaQuebrada.get(i) == 'o' || senhaQuebrada.get(i) == 'p'
                    || senhaQuebrada.get(i) == 'q' || senhaQuebrada.get(i) == 'r'
                    || senhaQuebrada.get(i) == 's' || senhaQuebrada.get(i) == 't'
                    || senhaQuebrada.get(i) == 'u' || senhaQuebrada.get(i) == 'v'
                    || senhaQuebrada.get(i) == 'w' || senhaQuebrada.get(i) == 'x'
                    || senhaQuebrada.get(i) == 'y' || senhaQuebrada.get(i) == 'z') {
                return true;
            }
        }
        return false;
    }

    //Busca por um caracter especial na senha informada no exercício 02
    public static boolean encontrouCaracterEspecial(List<Character> senhaQuebrada) {
        for (int i = 0; i < senhaQuebrada.size(); i++) {
            if (senhaQuebrada.get(i) == '!' || senhaQuebrada.get(i) == '@'
                    || senhaQuebrada.get(i) == '#' || senhaQuebrada.get(i) == '$'
                    || senhaQuebrada.get(i) == '%' || senhaQuebrada.get(i) == '^'
                    || senhaQuebrada.get(i) == '&' || senhaQuebrada.get(i) == '*'
                    || senhaQuebrada.get(i) == '(' || senhaQuebrada.get(i) == ')'
                    || senhaQuebrada.get(i) == '-' || senhaQuebrada.get(i) == '+') {
                return true;
            }
        }
        return false;
    }
    
    //Busca por pares de letras iguais na palavra informada no exercício 03
    public static int compararLetrasIguais(List<Character> palavraQuebrada){
        int n = 0;
        for (int i = 0; i < palavraQuebrada.size(); i++) {
            for (int j = (i + 1); j < palavraQuebrada.size(); j++) {
                if (palavraQuebrada.get(i) == palavraQuebrada.get(j)) {
                    n++;
                }
            }
        }
        return n;
    }
    
    /*
    public static int compararSubStringsIguais(List<Character> palavraQuebrada){
        Não consegui desenvolver a solução completa para essa questão! :(
    }
    */

    public static void main(String[] args) {
        questao01();
        questao02();
        questao03();
    }

}
